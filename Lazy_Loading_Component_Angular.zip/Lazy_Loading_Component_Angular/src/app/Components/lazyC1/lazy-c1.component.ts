import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './lazy-c1.component.html',
  styleUrls: ['./lazy-c1.component.css']
})
export class LazyC1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }
  

}
