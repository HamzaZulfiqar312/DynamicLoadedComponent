 export class User{

    user_name: string ; 
    pasword: string ;

    constructor()
    {
        this.user_name=''
        this.pasword=''
    }
}